#ifndef INC_KEYPAD_H_
#define INC_KEYPAD_H_

#include "main.h"

char read_keypad(void);

#endif 